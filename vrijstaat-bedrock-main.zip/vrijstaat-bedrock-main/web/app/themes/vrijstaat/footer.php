                <footer class="container">
                    <div class="row align-items-center text-center mt-5">
                        <div class="col-12 col-md-4">
                            <h4>Cardano</h4>
                            <?php wp_nav_menu([
                                "theme_location" => "footer_row_1",
                                'container' => "",
                                'items_wrap' => '<ul>%3$s</ul>',
                                'walker' => new footer_nav_walker()
                            ]);?>
                        </div>
                        <div class="col-12 col-md-4">
                            <img class="img-fluid footer-logo d-none d-md-inline" src="<?= get_home_url() ?>/app/uploads/2023/10/cardano-spinning.gif">
                            <h4>Get Involved</h4>
                            <?php wp_nav_menu([
                                "theme_location" => "footer_row_2",
                                'container' => "",
                                'items_wrap' => '<ul>%3$s</ul>',
                                'walker' => new footer_nav_walker()
                            ]);?>
                        </div>
                        <div class="col-12 col-md-4">
                            <h4>Website</h4>
                            <?php wp_nav_menu([
                                "theme_location" => "footer_row_3",
                                'container' => "",
                                'items_wrap' => '<ul>%3$s</ul>',
                                'walker' => new footer_nav_walker()
                            ]);?>
                        </div>
                    </div>            
                    <div class="row my-5 text-center pt-1">
                        <div class="col-12">
                            <p class="pb-3">© 2020-<?= date("Y");?> Vrijstaat Stakepool. All rights reserved.</p>
                            <img class="img-fluid footer-logo d-md-none" src="<?= get_home_url() ?>/app/uploads/2023/10/cardano-spinning.gif">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php wp_footer()?>
        <script type="text/javascript">
            var options = {
                particleColor: '#8DABC6',
                background: '#d3e5fd',
                interactive: 0,
                speed: 'medium',
                density: 'high'
            };
			var particleCanvas = new ParticleNetwork(document.getElementById('particle-canvas'), options);
		</script>
    </body>
</html>