<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    <head>
	    <meta charset="<?php bloginfo('charset');?>">
        <meta content="width=device-width, initial-scale=1" name="viewport">
        <?php wp_head();?>
    </head>
    <body>
        <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg sticky-top">
                <div class="container-fluid px-3">
                    <a class="navbar-brand" href="<?= get_home_url() ?>">
                        <?php
                            $custom_logo_id = get_theme_mod('custom_logo');
                            $image = wp_get_attachment_image_src($custom_logo_id , 'full');
                        ?>
                        <img class="header-logo" src="<?= $image[0] ?>">
                    </a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <?php wp_nav_menu([
                            "theme_location" => "nav_menu",
                            'container' => "",
                            'items_wrap' => '<ul class="navbar-nav me-auto align-items-center">%3$s</ul>',
                            'walker' => new bootstrap_5_nav_menu_walker()
                        ]);?>
                    </div>
                </div>
            </nav>
            <div>