#!/bin/sh
curl -X POST -s --data-urlencode "input={$(cat web/app/themes/vrijstaat/style.css)}" https://www.toptal.com/developers/cssminifier/api/raw > web/app/themes/vrijstaat/style.min.css
