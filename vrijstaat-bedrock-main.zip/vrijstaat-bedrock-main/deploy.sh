#!/bin/sh
# This logs into the server, executes the necessary commands to log into GitHub
# then pulls the new commits in. Then it runs composer install and kills the ssh-agent.

ssh -t thijs@the-exit.com -p 1986 "doas bastille cmd shared-hosting bash -c \
'exec ssh-agent bash -c \" \
ssh-add ~/.ssh/id_deploy_vrijstaat && \
cd /usr/local/www/vrijstaat-bedrock && \
git pull && \
composer install ; \
killall ssh-agent \" '"